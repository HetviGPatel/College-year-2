import os
from datetime import datetime

TENANT_FILE = "tenants.txt"

# class Tenant:
#     def __init__(self, tenant_id, name, age, room_no, ac, sharing, rent_paid, emergency_contact, password):
#         self.tenant_id = tenant_id
#         self.name = name
#         self.age = age
#         self.room_no = room_no
#         self.ac = ac
#         self.sharing = sharing
#         self.rent_paid = rent_paid
#         self.emergency_contact = emergency_contact
#         self.password = password

#     def to_string(self):
#         return f"{self.tenant_id} | {self.name} | {self.age} | {self.room_no} | {self.ac} | {self.sharing} | {self.rent_paid} | {self.emergency_contact} | {self.password}"

# Function to generate a unique Tenant ID
def generate_tenant_id():
    if not os.path.exists(TENANT_FILE):
        return "T001"

    with open(TENANT_FILE, "r") as file:
        lines = file.readlines()
        if not lines:
            return "T001"

        last_tenant = lines[-1].split(" | ")[0]  # Get last Tenant ID
        last_number = int(last_tenant[1:])  # Extract number from "T001"
        new_id = f"T{last_number + 1:03d}"  # Format as "T002", "T003"
        return new_id

# Function to delete a tenant
def delete_tenant(tenant_id):
    if not os.path.exists(TENANT_FILE):
        return False

    with open(TENANT_FILE, "r") as file:
        lines = file.readlines()

    found = False
    with open(TENANT_FILE, "w") as file:
        for line in lines:
            if line.startswith(tenant_id + " | "):
                found = True
                continue  # Skip writing this line (removing tenant)
            file.write(line)

    return found  # Return True if tenant was removed, False if not found



TENANT_FILE = "tenants.txt"
RECEIPT_FOLDER = "receipts"

# Ensure receipts folder exists
if not os.path.exists(RECEIPT_FOLDER):
    os.makedirs(RECEIPT_FOLDER)

def update_rent_status(tenant_id):
    if not os.path.exists(TENANT_FILE):
        return False
    
    lines = []
    tenant_found = False
    tenant_name = ""
    room_no = ""
    rent_amount = "5000"  # Default rent amount (Can be dynamic later)
    payment_date = datetime.now().strftime("%Y-%m-%d")  # Current date

    with open(TENANT_FILE, "r") as file:
        for line in file:
            data = line.strip().split(" | ")
            if data[0] == tenant_id:
                tenant_found = True
                tenant_name = data[1]
                room_no = data[3]
                data[-3] = "Paid"  # Update rent status
                line = " | ".join(data) + "\n"  # Recreate line

            lines.append(line)

    if tenant_found:
        with open(TENANT_FILE, "w") as file:
            file.writelines(lines)

        # Generate rent receipt
        receipt_content = f"""
        StayEase - Rent Receipt
        ----------------------------
        Tenant ID   : {tenant_id}
        Name        : {tenant_name}
        Room No.    : {room_no}
        Rent Amount : Rs. {rent_amount}
        Payment Date: {payment_date}
        Status      : PAID
        ----------------------------
        Thank you for your payment!
        """

        receipt_path = os.path.join(RECEIPT_FOLDER, f"{tenant_id}_receipt.txt")
        with open(receipt_path, "w") as receipt_file:
            receipt_file.write(receipt_content)

        return True

    return False


def get_unpaid_tenants():
    """Returns a list of tenants with unpaid rent"""
    unpaid_tenants = []

    if os.path.exists(TENANT_FILE):
        with open(TENANT_FILE, "r") as file:
            for line in file:
                data = line.strip().split(" | ")
                if data[-3] == "Unpaid":  # Rent status column
                    unpaid_tenants.append((data[0], data[1]))  # (Tenant ID, Name)

    return unpaid_tenants


def save_tenant(name, age, room_no, ac, sharing, emergency_contact, password, gender):
    tenant_id = generate_tenant_id()
    rent_status = "Unpaid"  # Ensure rent status is always stored
    tenant_data = f"{tenant_id} | {name} | {age} | {room_no} | {ac} | {sharing} | {emergency_contact} | {rent_status} | {password} | {gender}\n"

    with open(TENANT_FILE, "a") as file:
        file.write(tenant_data)

    return tenant_id
