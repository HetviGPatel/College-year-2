import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import matplotlib.pyplot as plt
import os
from tenants import save_tenant, delete_tenant,update_rent_status ,get_unpaid_tenants # Import 
from rooms import save_room, delete_room
from complaints import update_complaint_status
from feedback import get_feedback_summary


TENANT_FILE = "tenants.txt"

def generate_tenant_id():
    if not os.path.exists(TENANT_FILE):
        return "T001"  # Start with the first ID if file doesn't exist
    
    with open(TENANT_FILE, "r") as file:
        lines = file.readlines()
        if not lines:
            return "T001"  # If file is empty, start from T001
        
        last_tenant = lines[-1].split(" | ")[0]  # Extract last Tenant ID
        last_number = int(last_tenant[1:])  # Extract number part from "T001"
        new_id = f"T{last_number + 1:03d}"  # Format as "T002", "T003", etc.
        
        return new_id

# Function to get the number of tenants in a room
def count_tenants_in_room(room_no):
    tenant_count = 0
    try:
        with open("tenants.txt", "r") as tenant_file:
            for line in tenant_file:
                parts = line.strip().split(" | ")
                if len(parts) == 8 and parts[3] == room_no:  # Tenant room number
                    tenant_count += 1
    except FileNotFoundError:
        messagebox.showerror("Error", "Tenant file not found!")
    return tenant_count


# Function to open Add Tenant window

# def open_add_tenant_window():
#     add_window = tk.Toplevel()
#     add_window.title("Add Tenant")
#     add_window.geometry("400x400")

#     # Generate Tenant ID and Get Current Date
#     tenant_id = generate_tenant_id()  # Now correctly formatted as "T001"
#     current_date = datetime.now().strftime("%Y-%m-%d")

#     tk.Label(add_window, text=f"Tenant ID: {tenant_id}").pack()
#     tk.Label(add_window, text=f"Current Date: {current_date}").pack()

#     tk.Label(add_window, text="Tenant Name:").pack()
#     entry_name = tk.Entry(add_window)
#     entry_name.pack()

#     tk.Label(add_window, text="Age:").pack()
#     entry_age = tk.Entry(add_window)
#     entry_age.pack()

#     tk.Label(add_window, text="A/C Room:").pack()
#     ac_var = tk.StringVar(value="AC")  # Default: AC

#     # 🔹 Function to update available rooms based on selection
#     def update_room_dropdown():
#         selected_ac = ac_var.get()
#         selected_sharing = sharing_var.get()
#         print("LINE 71:",selected_ac,selected_sharing)
#         # Load available rooms from rooms.txt
#         available_rooms = []
#         try:
#             with open("rooms.txt", "r") as file:
#                 with open("tenants.txt", "r") as tenant_file:
#                     rooms = {}
#                     for line in tenant_file:
#                         tenant_parts = line.strip().split(" | ")
#                         print("LINE 80:",tenant_parts)
#                         if len(tenant_parts) == 9:
#                             room_no = tenant_parts[3]
#                             rooms[room_no] = rooms.get(room_no,0)+1
#                     print("LINE 83:",rooms)
#                     for line in file:
#                         parts = line.strip().split(" | ")
#                         print("LINE 86:",parts)
#                         if len(parts) == 4:
#                             room_no, ac_status, capacity, status = parts
#                             # if status.lower() == "available" and ac_status == selected_ac and capacity == selected_sharing:
#                             if ac_status == selected_ac:
#                                 if selected_sharing == '2' and capacity >= selected_sharing and not (room_no in rooms and int(rooms[room_no])>=int(capacity)):
#                                     available_rooms.append(room_no)
#                                     print("LINE 93:",available_rooms)
#                                 elif selected_sharing == '1' and capacity == '1' and not (room_no in rooms and int(rooms[room_no])>=int(capacity)):
#                                     available_rooms.append(room_no)
#                                     print("LINE 96:",available_rooms)
#         except FileNotFoundError:
#             messagebox.showerror("Error", "Rooms file not found!")

#         # Update dropdown
#         # room_dropdown["menu"].delete(0, "end")
#         # for room in available_rooms:
#         #     room_dropdown["menu"].add_command(label=room, command=tk._setit(selected_room, room))
        
#         # if available_rooms:
#         #     selected_room.set(available_rooms[0])  # Set default to first available room
#         # else:
#         #     selected_room.set("No Rooms Available")
#         menu = room_dropdown["menu"]
#         menu.delete(0, "end")  # Clear existing menu options
#         if available_rooms:
#             for room in available_rooms:
#                 menu.add_command(label=room, command=tk._setit(selected_room, room))  # Add each available room
#             selected_room.set(available_rooms[0])  # Default to first available room
#         else:
#             menu.add_command(label="No Rooms Available", command=tk._setit(selected_room, "No Rooms Available"))  # Display a "No Rooms Available" message
#             selected_room.set("No Rooms Available")  # Set this as the selected room

#     tk.Radiobutton(add_window, text="A/C", variable=ac_var, value="AC", command=update_room_dropdown).pack()
#     tk.Radiobutton(add_window, text="Non-A/C", variable=ac_var, value="Non-AC", command=update_room_dropdown).pack()

#     tk.Label(add_window, text="Sharing:").pack()
#     sharing_var = tk.StringVar(value="1")  # Default: Single occupancy
#     tk.Radiobutton(add_window, text="Single", variable=sharing_var, value="1", command=update_room_dropdown).pack()
#     tk.Radiobutton(add_window, text="Sharing", variable=sharing_var, value="2", command=update_room_dropdown).pack()

#     tk.Label(add_window, text="Room No:").pack()
#     selected_room = tk.StringVar()
#     room_dropdown = tk.OptionMenu(add_window, selected_room, "Select A/C & Sharing First")
#     room_dropdown.pack()

#     tk.Label(add_window, text="Emergency Contact:").pack()
#     entry_emergency = tk.Entry(add_window)
#     entry_emergency.pack()

#     tk.Label(add_window, text="Set Password:").pack()
#     entry_password = tk.Entry(add_window, show="*")
#     entry_password.pack()

#     # Call update to initialize dropdown
#     update_room_dropdown()

#     def add_tenant():
#         name = entry_name.get()
#         age = entry_age.get()
#         room_no = selected_room.get()
#         ac = ac_var.get()
#         sharing = sharing_var.get()
#         emergency_contact = entry_emergency.get()
#         password = entry_password.get()

#         if not (name and age and room_no and ac and sharing and emergency_contact and password):
#             messagebox.showerror("Error", "All fields are required!")
#             return

#         if room_no == "No Rooms Available":
#             messagebox.showerror("Error", "No available rooms for selected type!")
#             return

#         if not (emergency_contact.isdigit() and len(emergency_contact) == 10):
#             messagebox.showerror("Error", "Emergency Contact must be a 10-digit number!")
#             return

#         if not (age.isdigit() and int(age) > 0):
#             messagebox.showerror("Error", "Age must be a positive number!")
#             return

#         # Step 1: Load room details from rooms.txt
#         room_capacity = 0
#         room_status = ""
#         try:
#             with open("rooms.txt", "r") as file:
#                 for line in file:
#                     parts = line.strip().split(" | ")
#                     if len(parts) == 4 and parts[0] == room_no:
#                         room_capacity = int(parts[2])  # Room capacity
#                         room_status = parts[3]  # Room status
#                         break
#         except FileNotFoundError:
#             messagebox.showerror("Error", "Rooms file not found!")
#             return

#         # if room_status.lower() != "available":
#         #     messagebox.showerror("Error", f"Room {room_no} is not available!")
#         #     return

#         # Step 2: Count existing tenants in the room
#         tenants_in_room = count_tenants_in_room(room_no)

#         # Step 3: Check if the room has reached its capacity
#         if tenants_in_room >= room_capacity:
#             messagebox.showerror("Error", f"Room {room_no} is already full!")
#             return

#         # Step 4: Add tenant and update room status
#         try:
#             with open("rooms.txt", "r") as file:
#                 lines = file.readlines()

#             with open("rooms.txt", "w") as file:
#                 for line in lines:
#                     parts = line.strip().split(" | ")
#                     if len(parts) == 4 and parts[0] == room_no:
#                         file.write(f"{room_no} | {ac} | {sharing} | Occupied\n")  # Mark room as occupied
#                     else:
#                         file.write(line)
#         except FileNotFoundError:
#             messagebox.showerror("Error", "Rooms file not found!")
#             return

#         # Save tenant info (This would depend on how you handle saving tenant data in your system)
#         tenant_id = save_tenant(name, age, room_no, ac, sharing, emergency_contact, password)

#         messagebox.showinfo("Success", f"Tenant {tenant_id} added successfully! Room {room_no} is now occupied.")

#         add_window.destroy()


#     tk.Button(add_window, text="Add Tenant", command=add_tenant).pack()

def open_add_tenant_window():
    add_window = tk.Toplevel()
    add_window.title("Add Tenant")
    add_window.geometry("400x450")  # Adjusted size to fit gender selection

    # Generate Tenant ID and Get Current Date
    tenant_id = generate_tenant_id()  
    current_date = datetime.now().strftime("%Y-%m-%d")

    tk.Label(add_window, text=f"Tenant ID: {tenant_id}").pack()
    tk.Label(add_window, text=f"Current Date: {current_date}").pack()

    tk.Label(add_window, text="Tenant Name:").pack()
    entry_name = tk.Entry(add_window)
    entry_name.pack()

    tk.Label(add_window, text="Age:").pack()
    entry_age = tk.Entry(add_window)
    entry_age.pack()

    # 🔹 Gender Selection (Radio Buttons)
    tk.Label(add_window, text="Gender:").pack()
    gender_var = tk.StringVar(value="Male")  # Default selection
    tk.Radiobutton(add_window, text="Male", variable=gender_var, value="Male").pack()
    tk.Radiobutton(add_window, text="Female", variable=gender_var, value="Female").pack()

    # A/C Room Selection
    tk.Label(add_window, text="A/C Room:").pack()
    ac_var = tk.StringVar(value="AC")

    def update_room_dropdown():
        selected_ac = ac_var.get()
        selected_sharing = sharing_var.get()
        available_rooms = []
        try:
            with open("rooms.txt", "r") as file:
                with open("tenants.txt", "r") as tenant_file:
                    rooms = {}
                    for line in tenant_file:
                        tenant_parts = line.strip().split(" | ")
                        if len(tenant_parts) == 9:
                            room_no = tenant_parts[3]
                            rooms[room_no] = rooms.get(room_no, 0) + 1

                    for line in file:
                        parts = line.strip().split(" | ")
                        if len(parts) == 4:
                            room_no, ac_status, capacity, status = parts
                            if ac_status == selected_ac:
                                if selected_sharing == '2' and capacity >= selected_sharing and not (room_no in rooms and int(rooms[room_no]) >= int(capacity)):
                                    available_rooms.append(room_no)
                                elif selected_sharing == '1' and capacity == '1' and not (room_no in rooms and int(rooms[room_no]) >= int(capacity)):
                                    available_rooms.append(room_no)
        except FileNotFoundError:
            messagebox.showerror("Error", "Rooms file not found!")

        # Update dropdown
        menu = room_dropdown["menu"]
        menu.delete(0, "end")
        if available_rooms:
            for room in available_rooms:
                menu.add_command(label=room, command=tk._setit(selected_room, room))
            selected_room.set(available_rooms[0])  
        else:
            menu.add_command(label="No Rooms Available", command=tk._setit(selected_room, "No Rooms Available"))
            selected_room.set("No Rooms Available")

    tk.Radiobutton(add_window, text="A/C", variable=ac_var, value="AC", command=update_room_dropdown).pack()
    tk.Radiobutton(add_window, text="Non-A/C", variable=ac_var, value="Non-AC", command=update_room_dropdown).pack()

    # Sharing Option
    tk.Label(add_window, text="Sharing:").pack()
    sharing_var = tk.StringVar(value="1")
    tk.Radiobutton(add_window, text="Single", variable=sharing_var, value="1", command=update_room_dropdown).pack()
    tk.Radiobutton(add_window, text="Sharing", variable=sharing_var, value="2", command=update_room_dropdown).pack()

    # Room Selection Dropdown
    tk.Label(add_window, text="Room No:").pack()
    selected_room = tk.StringVar()
    room_dropdown = tk.OptionMenu(add_window, selected_room, "Select A/C & Sharing First")
    room_dropdown.pack()

    # Emergency Contact
    tk.Label(add_window, text="Emergency Contact:").pack()
    entry_emergency = tk.Entry(add_window)
    entry_emergency.pack()

    # Password
    tk.Label(add_window, text="Set Password:").pack()
    entry_password = tk.Entry(add_window, show="*")
    entry_password.pack()

    # Call update to initialize dropdown
    update_room_dropdown()

    # 🔹 Function to Add Tenant
    def add_tenant():
        name = entry_name.get()
        age = entry_age.get()
        gender = gender_var.get()  # Get selected gender
        room_no = selected_room.get()
        ac = ac_var.get()
        sharing = sharing_var.get()
        emergency_contact = entry_emergency.get()
        password = entry_password.get()

        if not (name and age and gender and room_no and ac and sharing and emergency_contact and password):
            messagebox.showerror("Error", "All fields are required!")
            return

        if room_no == "No Rooms Available":
            messagebox.showerror("Error", "No available rooms for selected type!")
            return

        if not (emergency_contact.isdigit() and len(emergency_contact) == 10):
            messagebox.showerror("Error", "Emergency Contact must be a 10-digit number!")
            return

        if not (age.isdigit() and int(age) > 0):
            messagebox.showerror("Error", "Age must be a positive number!")
            return

        # Step 1: Load room details from rooms.txt
        room_capacity = 0
        try:
            with open("rooms.txt", "r") as file:
                for line in file:
                    parts = line.strip().split(" | ")
                    if len(parts) == 4 and parts[0] == room_no:
                        room_capacity = int(parts[2])  # Room capacity
                        break
        except FileNotFoundError:
            messagebox.showerror("Error", "Rooms file not found!")
            return

        # Step 2: Count existing tenants in the room
        tenants_in_room = count_tenants_in_room(room_no)

        # Step 3: Check if the room has reached its capacity
        if tenants_in_room >= room_capacity:
            messagebox.showerror("Error", f"Room {room_no} is already full!")
            return

        # Step 4: Add tenant and update room status
        try:
            with open("rooms.txt", "r") as file:
                lines = file.readlines()

            with open("rooms.txt", "w") as file:
                for line in lines:
                    parts = line.strip().split(" | ")
                    if len(parts) == 4 and parts[0] == room_no:
                        file.write(f"{room_no} | {ac} | {sharing} | Occupied\n")  # Mark room as occupied
                    else:
                        file.write(line)
        except FileNotFoundError:
            messagebox.showerror("Error", "Rooms file not found!")
            return

        # Save tenant info
        tenant_id = save_tenant(name, age, room_no, ac, sharing, emergency_contact, password,gender)

        messagebox.showinfo("Success", f"Tenant {tenant_id} added successfully! Room {room_no} is now occupied.")

        add_window.destroy()

    tk.Button(add_window, text="Add Tenant", command=add_tenant).pack()


# Function to open Remove Tenant window
# def open_remove_tenant_window():
#     remove_window = tk.Toplevel()
#     remove_window.title("Remove Tenant")
#     remove_window.geometry("300x200")

#     tk.Label(remove_window, text="Enter Tenant ID to Remove:").pack()
#     entry_tenant_id = tk.Entry(remove_window)
#     entry_tenant_id.pack()

#     def remove_tenant():
#         tenant_id = entry_tenant_id.get()
#         if not tenant_id:
#             messagebox.showerror("Error", "Please enter a Tenant ID")
#             return

#         result = delete_tenant(tenant_id)  # Now correctly calls delete_tenant()

#         if result:
#             messagebox.showinfo("Success", f"Tenant {tenant_id} removed successfully!")
#             remove_window.destroy()
#         else:
#             messagebox.showerror("Error", f"Tenant {tenant_id} not found!")

#     tk.Button(remove_window, text="Remove", command=remove_tenant).pack()

TENANT_FILE = "tenants.txt"
PAST_TENANT_FILE = "past_tenant.txt"

# 🔹 Function to Open Remove Tenant Window
def open_remove_tenant_window():
    remove_window = tk.Toplevel()
    remove_window.title("Remove Tenant")
    remove_window.geometry("300x200")

    tk.Label(remove_window, text="Enter Tenant ID to Remove:", font=("Arial", 12)).pack(pady=5)
    entry_tenant_id = tk.Entry(remove_window, font=("Arial", 12))
    entry_tenant_id.pack(pady=5)

    def remove_tenant():
        tenant_id = entry_tenant_id.get().strip()
        if not tenant_id:
            messagebox.showerror("Error", "Please enter a Tenant ID")
            return

        result = delete_tenant(tenant_id)  # Updated to correctly remove tenant

        if result:
            messagebox.showinfo("Success", f"Tenant {tenant_id} removed successfully!")
            remove_window.destroy()
        else:
            messagebox.showerror("Error", f"Tenant {tenant_id} not found!")

    tk.Button(remove_window, text="Remove", font=("Arial", 12, "bold"), bg="#E53935", fg="white",
              width=12, command=remove_tenant).pack(pady=10)

# 🔹 Function to Delete Tenant & Store in `past_tenant.txt`
def delete_tenant(tenant_id):
    tenant_found = False
    tenants = []

    try:
        with open(TENANT_FILE, "r") as file:
            lines = file.readlines()

        with open(TENANT_FILE, "w") as file:
            for line in lines:
                data = line.strip().split(" | ")
                if data and data[0] == tenant_id:  # Check if first field matches Tenant ID
                    tenant_found = True
                    store_past_tenant(line)  # Store in `past_tenant.txt`
                else:
                    tenants.append(line)

            file.writelines(tenants)  # Rewrite `tenants.txt` without the removed tenant

    except FileNotFoundError:
        messagebox.showerror("Error", "Tenant data file not found!")
        return False

    return tenant_found

# 🔹 Function to Store Removed Tenant in `past_tenant.txt`
def store_past_tenant(tenant_data):
    try:
        with open(PAST_TENANT_FILE, "a") as file:
            file.write(tenant_data)  # Append tenant data
    except FileNotFoundError:
        messagebox.showerror("Error", "Past tenant file not found!")



def view_tenant_details():
    """Opens a new window to enter Tenant ID and view details."""
    view_window = tk.Toplevel()
    view_window.title("View Tenant Details")
    view_window.geometry("400x200")

    tk.Label(view_window, text="Enter Tenant ID:").pack(pady=5)
    
    entry_tenant_id = tk.Entry(view_window)
    entry_tenant_id.pack(pady=5)

    def fetch_details():
        tenant_id = entry_tenant_id.get().strip()
        if not tenant_id:
            messagebox.showerror("Error", "Please enter a Tenant ID!")
            return
        
        try:
            with open(TENANT_FILE, "r") as file:
                for line in file:
                    data = line.strip().split(" | ")
                    if len(data) >= 7 and data[0] == tenant_id:  # Ensure correct format
                        tenant_info = (
                            f"Tenant ID: {data[0]}\n"
                            f"Name: {data[1]}\n"
                            f"Age: {data[2]}\n"
                            f"Gender: {data[-1]}\n"
                            f"Room No: {data[3]}\n"
                            f"A/C Room: {data[4]}\n"
                            f"Emergency Contact: {data[6]}"
                        )
                        messagebox.showinfo("Tenant Details", tenant_info)
                        return
            
            messagebox.showerror("Error", "Tenant ID not found!")

        except FileNotFoundError:
            messagebox.showerror("Error", "Tenant data file not found!")

    # 🔹 Added Button Below Entry Field
    tk.Button(view_window, text="View Details", command=fetch_details).pack(pady=10)



def open_add_room_window():
    add_room_window = tk.Toplevel()
    add_room_window.title("Add Room")
    add_room_window.geometry("300x250")

    tk.Label(add_room_window, text="Room Number:").pack()
    entry_room_no = tk.Entry(add_room_window)
    entry_room_no.pack()

    tk.Label(add_room_window, text="A/C Room (Yes/No):").pack()
    entry_ac = tk.Entry(add_room_window)
    entry_ac.pack()

    tk.Label(add_room_window, text="Sharing (Yes/No):").pack()
    entry_sharing = tk.Entry(add_room_window)
    entry_sharing.pack()

    # Always show the capacity field
    tk.Label(add_room_window, text="Capacity:").pack()
    entry_capacity = tk.Entry(add_room_window)
    entry_capacity.pack()

    # Function to update capacity based on sharing selection
    def update_capacity_field():
        sharing = entry_sharing.get().strip().lower()

        if sharing == 'yes':
            # Allow the user to enter the capacity if sharing is 'yes'
            entry_capacity.config(state="normal")  # Enable entry for capacity
            entry_capacity.delete(0, tk.END)  # Clear previous value
        elif sharing == 'no':
            # Automatically set capacity to 1 if sharing is 'no' and make it readonly
            entry_capacity.delete(0, tk.END)
            entry_capacity.insert(0, "1")  # Set capacity to 1
            entry_capacity.config(state="readonly")  # Disable editing the capacity

    # Call the update_capacity_field function to reflect initial state when the sharing field is filled
    entry_sharing.bind("<FocusOut>", lambda event: update_capacity_field())

    def add_room():
        room_no = entry_room_no.get()
        ac = entry_ac.get().strip().lower()
        sharing = entry_sharing.get().strip().lower()

        # Validate sharing input
        if sharing not in ["yes", "no"]:
            messagebox.showerror("Error", "Sharing must be either 'Yes' or 'No'.")
            return

        # Determine capacity
        if sharing == 'yes':
            # If sharing is yes, we ask for capacity as input
            if not entry_capacity.get().isdigit():
                messagebox.showerror("Error", "Capacity must be a number!")
                return
            capacity = int(entry_capacity.get())
        elif sharing == 'no':
            # If sharing is no, capacity is set to 1 by default
            capacity = 1
        
        # Validate other fields
        if not room_no or ac not in ["yes", "no"]:
            messagebox.showerror("Error", "Invalid input! Fill all fields correctly.")
            return

        # Save the room (assuming save_room function handles the data persistence)
        if save_room(room_no, ac, sharing, capacity):
            messagebox.showinfo("Success", f"Room {room_no} added successfully!")
            add_room_window.destroy()
        else:
            messagebox.showerror("Error", "Room already exists!")

    # Add room button
    btn_add = tk.Button(add_room_window, text="Add Room", command=add_room)
    btn_add.pack()

def open_remove_room_window():
    remove_room_window = tk.Toplevel()
    remove_room_window.title("Remove Room")
    remove_room_window.geometry("300x200")

    tk.Label(remove_room_window, text="Enter Room Number to Remove:").pack()
    entry_room_no = tk.Entry(remove_room_window)
    entry_room_no.pack()

    def remove_room():
        room_no = entry_room_no.get()
        if not room_no:
            messagebox.showerror("Error", "Please enter a Room Number")
            return

        result = delete_room(room_no)

        if result:
            messagebox.showinfo("Success", f"Room {room_no} removed successfully!")
            remove_room_window.destroy()
        else:
            messagebox.showerror("Error", f"Room {room_no} is either occupied or doesn't exist!")

    btn_remove = tk.Button(remove_room_window, text="Remove Room", command=remove_room)
    btn_remove.pack()


def open_mark_rent_window():
    mark_rent_window = tk.Toplevel()
    mark_rent_window.title("Mark Rent as Paid")
    mark_rent_window.geometry("300x200")

    tk.Label(mark_rent_window, text="Enter Tenant ID:").pack()
    entry_tenant_id = tk.Entry(mark_rent_window)
    entry_tenant_id.pack()

    def mark_rent_paid():
        tenant_id = entry_tenant_id.get()
        if not tenant_id:
            messagebox.showerror("Error", "Please enter a Tenant ID")
            return

        result = update_rent_status(tenant_id)  # Call function to update rent status

        if result:
            messagebox.showinfo("Success", f"Rent marked as paid for {tenant_id}\nReceipt generated successfully!")
            mark_rent_window.destroy()
        else:
            messagebox.showerror("Error", f"Tenant {tenant_id} not found!")

    btn_mark = tk.Button(mark_rent_window, text="Mark as Paid", command=mark_rent_paid)
    btn_mark.pack()


def open_complaint_list():
    complaint_window = tk.Toplevel()
    complaint_window.title("Complaints List")
    complaint_window.geometry("500x300")

    tk.Label(complaint_window, text="Pending Complaints:").pack()

    with open("complaints.txt", "r") as file:
        lines = file.readlines()

    for line in lines:
        data = line.strip().split(" | ")
        if data[-1] == "Pending":  # Show only pending complaints
            tk.Label(complaint_window, text=f"{data[0]} - {data[2]} - {data[3]} (Due: {data[5]})").pack()

    tk.Label(complaint_window, text="Enter Complaint ID to Resolve:").pack()
    entry_complaint_id = tk.Entry(complaint_window)
    entry_complaint_id.pack()

    def resolve_complaint():
        complaint_id = entry_complaint_id.get()
        if not complaint_id:
            messagebox.showerror("Error", "Enter Complaint ID")
            return

        if update_complaint_status(complaint_id):
            messagebox.showinfo("Success", f"Complaint {complaint_id} resolved!")
            complaint_window.destroy()
        else:
            messagebox.showerror("Error", "Invalid Complaint ID!")

    btn_resolve = tk.Button(complaint_window, text="Resolve Complaint", command=resolve_complaint)
    btn_resolve.pack()



VISITOR_FILE = "visitors.txt"

def view_visitors():
    if not os.path.exists(VISITOR_FILE):
        messagebox.showinfo("Info", "No visitor records found!")
        return

    visitor_window = tk.Toplevel()
    visitor_window.title("Visitor Log")
    visitor_window.geometry("500x400")

    tk.Label(visitor_window, text="Visitor Logs", font=("Arial", 14)).pack()

    with open(VISITOR_FILE, "r") as file:
        visitors = [line.strip().split(" | ") for line in file.readlines()]

    for visitor in visitors:
        tenant_id, name, purpose, checkin_time, status = visitor

        visitor_label = tk.Label(visitor_window, text=f"{tenant_id} | {name} | {purpose} | {checkin_time} | {status}")
        visitor_label.pack()

        if status == "Pending":  # Only show checkout button for pending visitors
            btn_checkout = tk.Button(visitor_window, text="Mark Checkout", command=lambda v=visitor: mark_checkout(v, visitor_window))
            btn_checkout.pack()

def mark_checkout(visitor, window):
    tenant_id, name, purpose, checkin_time, status = visitor

    with open(VISITOR_FILE, "r") as file:
        lines = file.readlines()

    with open(VISITOR_FILE, "w") as file:
        for line in lines:
            if line.strip().startswith(f"{tenant_id} | {name} | {purpose} | {checkin_time}"):
                file.write(f"{tenant_id} | {name} | {purpose} | {checkin_time} | Checked Out\n")
            else:
                file.write(line)

    messagebox.showinfo("Success", f"Visitor {name} checked out!")
    window.destroy()  # Refresh the window
    view_visitors()   # Open updated log window

def send_rent_reminders():
    unpaid_tenants = get_unpaid_tenants()
    
    if not unpaid_tenants:
        messagebox.showinfo("Info", "All tenants have paid their rent!")
        return

    reminder_window = tk.Toplevel()
    reminder_window.title("Send Rent Reminders")
    reminder_window.geometry("300x300")

    tk.Label(reminder_window, text="Unpaid Tenants:", font=("Arial", 12)).pack()

    for tenant_id, name in unpaid_tenants:
        tk.Label(reminder_window, text=f"{tenant_id} - {name}").pack()

    def confirm_reminders():
        messagebox.showinfo("Success", "Rent reminders sent successfully!")
        reminder_window.destroy()

    btn_send = tk.Button(reminder_window, text="Send Reminders", command=confirm_reminders)
    btn_send.pack()


MAINTENANCE_FILE = "maintenance_requests.txt"  # File storing maintenance requests

# Function to load maintenance requests
def load_maintenance_requests():
    requests = []
    if not os.path.exists(MAINTENANCE_FILE):
        return requests

    with open(MAINTENANCE_FILE, "r") as file:
        for line in file:
            data = line.strip().split(" | ")
            if len(data) == 6:  # Ensure correct format
                requests.append(data)  # [request_id, tenant_id, issue_type, issue_details, date, status]
    
    return requests

# Function to mark a request as resolved
def resolve_maintenance_request(request_id):
    requests = load_maintenance_requests()
    updated_requests = []

    resolved = False
    for request in requests:
        if request[0] == request_id and request[-1] == "Pending":
            request[-1] = "Resolved"
            resolved = True
        updated_requests.append(request)

    if resolved:
        with open(MAINTENANCE_FILE, "w") as file:
            for request in updated_requests:
                file.write(" | ".join(request) + "\n")

        messagebox.showinfo("Success", f"Request {request_id} marked as Resolved!")
    else:
        messagebox.showerror("Error", "Request not found or already resolved!")

# Function to open the maintenance request management window
def open_maintenance_requests_window():
    window = tk.Toplevel()
    window.title("Manage Maintenance Requests")
    window.geometry("500x400")

    tk.Label(window, text="Maintenance Requests", font=("Arial", 14)).pack()

    requests = load_maintenance_requests()
    
    if not requests:
        tk.Label(window, text="No maintenance requests found!").pack()
        return

    for request in requests:
        request_text = f"ID: {request[0]} | Tenant: {request[1]} | Issue: {request[2]} | Status: {request[-1]}"
        label = tk.Label(window, text=request_text)
        label.pack()

        if request[-1] == "Pending":
            btn_resolve = tk.Button(window, text="Resolve", command=lambda req_id=request[0]: resolve_maintenance_request(req_id))
            btn_resolve.pack()



ROOMS_FILE = "rooms.txt"  # File storing room details

# Function to load rooms from file
def load_rooms():
    rooms = {"Available": [], "Occupied": [], "Under Maintenance": []}

    if not os.path.exists(ROOMS_FILE):
        return rooms

    with open(ROOMS_FILE, "r") as file:
        for line in file:
            data = line.strip().split(" | ")
            if len(data) == 4:
                room_id, room_type, capacity, status = data
                rooms[status].append((room_id, room_type, capacity))

    return rooms

# Function to display room availability
def open_room_availability_window():
    window = tk.Toplevel()
    window.title("Room Availability")
    window.geometry("500x400")

    tk.Label(window, text="Room Availability Status", font=("Arial", 14)).pack()

    rooms = load_rooms()
    
    for status, room_list in rooms.items():
        tk.Label(window, text=f"\n{status} Rooms:", font=("Arial", 12, "bold")).pack()
        if not room_list:
            tk.Label(window, text="No rooms available").pack()
        else:
            for room in room_list:
                tk.Label(window, text=f"Room {room[0]} | Type: {room[1]} | Capacity: {room[2]}").pack()




# Function to update room status
def update_room_status(room_id, new_status):
    if not os.path.exists(ROOMS_FILE):
        return False

    updated_rooms = []
    room_found = False

    with open(ROOMS_FILE, "r") as file:
        for line in file:
            data = line.strip().split(" | ")
            if len(data) == 4:
                current_room_id, room_type, capacity, status = data
                if current_room_id == room_id:
                    updated_rooms.append(f"{current_room_id} | {room_type} | {capacity} | {new_status}\n")
                    room_found = True
                else:
                    updated_rooms.append(line)

    if room_found:
        with open(ROOMS_FILE, "w") as file:
            file.writelines(updated_rooms)
        return True
    return False

# Function to open room status update window
def open_update_room_status_window():
    window = tk.Toplevel()
    window.title("Update Room Status")
    window.geometry("300x250")

    tk.Label(window, text="Enter Room ID:").pack()
    entry_room_id = tk.Entry(window)
    entry_room_id.pack()

    tk.Label(window, text="New Status (Available/Occupied/Under Maintenance):").pack()
    entry_new_status = tk.Entry(window)
    entry_new_status.pack()

    def update_status():
        room_id = entry_room_id.get().strip()
        new_status = entry_new_status.get().strip()

        if not room_id or not new_status:
            messagebox.showerror("Error", "Both fields are required!")
            return

        if new_status not in ["Available", "Occupied", "Under Maintenance"]:
            messagebox.showerror("Error", "Invalid status! Choose Available, Occupied, or Under Maintenance.")
            return

        if update_room_status(room_id, new_status):
            messagebox.showinfo("Success", f"Room {room_id} updated to {new_status}.")
            window.destroy()
        else:
            messagebox.showerror("Error", "Room ID not found!")

    btn_submit = tk.Button(window, text="Update Status", command=update_status)
    btn_submit.pack()



# def view_feedback():
#     """Display feedback summary in a popup."""
#     summary = get_feedback_summary()
#     messagebox.showinfo("Feedback Summary", summary)


FEEDBACK_FILE = "feedback.txt"

def generate_feedback_graph():
    """Read feedback data and generate an average rating bar chart."""
    total_food, total_cleanliness, total_service, count = 0, 0, 0, 0

    try:
        with open(FEEDBACK_FILE, "r") as file:
            for line in file:
                data = line.strip().split(" | ")
                if len(data) == 4:
                    total_food += int(data[1])
                    total_cleanliness += int(data[2])
                    total_service += int(data[3])
                    count += 1

        if count == 0:
            return

        avg_food = total_food / count
        avg_cleanliness = total_cleanliness / count
        avg_service = total_service / count

        # Creating bar chart
        categories = ["Food", "Cleanliness", "Services"]
        averages = [avg_food, avg_cleanliness, avg_service]

        plt.figure(figsize=(6, 4))
        plt.bar(categories, averages, color=['blue', 'green', 'red'])
        plt.xlabel("Categories")
        plt.ylabel("Average Rating")
        plt.ylim(0, 5)
        plt.title("Tenant Feedback Analysis")
        plt.show()

    except FileNotFoundError:
        print("No feedback data found!")




# Main Tkinter Window (Admin Dashboard)

def admin_dashboard():
    
    root = tk.Tk()
    root.title("Admin Dashboard")
    root.geometry("400x550")  # Adjusted size for better layout
    root.configure(bg="#E3F2FD")  # Light Blue Background

    # 🔹 Title Label
    tk.Label(root, text="Admin Dashboard", font=("Arial", 16, "bold"), bg="#E3F2FD").pack(pady=10)

    # 🔹 Function to create uniform buttons
    def create_button(text, command):
        return tk.Button(root, text=text, command=command, font=("Arial", 12), bg="#4CAF50", fg="white",    width=30)  # Same width & height for all buttons

    # 🔹 Buttons with Color, Uniform Size & Spacing
    create_button("Add Tenant", open_add_tenant_window).pack(pady=5)
    create_button("Remove Tenant", open_remove_tenant_window).pack(pady=5)
    create_button("View Tenant Details", view_tenant_details).pack(pady=5)

    create_button("Add Room", open_add_room_window).pack(pady=5)
    create_button("Remove Room", open_remove_room_window).pack(pady=5)
    create_button("Mark Rent as Paid", open_mark_rent_window).pack(pady=5)

    # create_button("View Feedback", view_feedback).pack(pady=5)
    create_button("View Feedback Analysis", generate_feedback_graph).pack(pady=5)
    create_button("View Complaints", open_complaint_list).pack(pady=5)

    create_button("Visitor Log", view_visitors).pack(pady=5)
    create_button("Check Rent Reminders", send_rent_reminders).pack(pady=5)
    create_button("Manage Maintenance Requests", open_maintenance_requests_window).pack(pady=5)

    create_button("Check Room Availability", open_room_availability_window).pack(pady=5)
    create_button("Update Room Status", open_update_room_status_window).pack(pady=5)

    root.mainloop()


