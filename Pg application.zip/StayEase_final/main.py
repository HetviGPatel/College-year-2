import tkinter as tk
from tkinter import messagebox
import os
from tenant_dashboard import tenant_dashboard  
from admin import admin_dashboard  



ADMIN_CREDENTIALS = "admin.txt"
TENANT_FILE = "tenants.txt"

def login():
    
    user_id = entry_username.get()
    password = entry_password.get()

    if not user_id or not password:
        messagebox.showerror("Error", "Please enter both ID and Password")
        return

    # Check Admin Credentials
    if os.path.exists(ADMIN_CREDENTIALS):
        with open(ADMIN_CREDENTIALS, "r") as file:
            admin_data = file.read().strip().split(" | ")
            if user_id == admin_data[0] and password == admin_data[1]:
                messagebox.showinfo("Success", "Admin Login Successful")
                root.destroy()  # Close login window
                admin_dashboard()  # Open Admin Dashboard
                return
            

    # Check Tenant Credentials
    if os.path.exists(TENANT_FILE):
        with open(TENANT_FILE, "r") as file:
            for line in file:
                data = line.strip().split(" | ")
                if user_id == data[0] and password == data[-2]:  
                    messagebox.showinfo("Success", "Tenant Login Successful")
                    root.destroy()  # Close login window
                    tenant_dashboard(user_id)  # Pass Tenant ID
                    return

    messagebox.showerror("Error", "Invalid ID or Password")


# Tkinter UI for Login Page
root = tk.Tk()
root.title("StayEase - PG Management")
root.geometry("350x250")
root.configure(bg="#E3F2FD")  # Light Blue Background

#  Frame for Padding & Centered UI
frame = tk.Frame(root, bg="white", padx=30, pady=30)
frame.place(relx=0.5, rely=0.5, anchor="center")

#  Title Label
tk.Label(frame, text="Login", font=("Arial", 16, "bold"), bg="white", fg="#333").pack(pady=10)

#  User ID Field
tk.Label(frame, text="User ID:", font=("Arial", 12), bg="white").pack(anchor="w")
entry_username = tk.Entry(frame, font=("Arial", 12))
entry_username.pack(pady=5, ipadx=5, ipady=3, fill="x")

#  Password Field
tk.Label(frame, text="Password:", font=("Arial", 12), bg="white").pack(anchor="w")
entry_password = tk.Entry(frame, font=("Arial", 12), show="*")
entry_password.pack(pady=5, ipadx=5, ipady=3, fill="x")

#  Login Button
btn_login = tk.Button(frame, text="Login", font=("Arial", 12, "bold"), bg="#4CAF50", fg="white",  padx=10, pady=5, command=login)
btn_login.pack(pady=15, fill="x")

root.mainloop()