import os

ROOM_FILE = "rooms.txt"
TENANT_FILE = "tenants.txt"


# class Room:
#     def __init__(self, room_no, ac, sharing, status):
#         self.room_no = room_no
#         self.ac = ac
#         self.sharing = sharing
#         self.status = status  # Available, Occupied, Maintenance



def save_room(room_no, ac, sharing, capacity):
    if not os.path.exists(ROOM_FILE):
        with open(ROOM_FILE, "w") as file:
            pass

    with open(ROOM_FILE, "r") as file:
        for line in file:
            if line.startswith(room_no + " | "):
                
                return False  # Room already exists

    with open(ROOM_FILE, "a") as file:
        print("ROOM:",room_no,ac,sharing,capacity)
        ac = "AC" if ac=='yes' else "Non-AC"
        sharing = "Yes" if sharing=='yes' else "No"
        file.write(f"{room_no} | {ac} | {capacity} | Available\n")

    return True

def delete_room(room_no):
    if not os.path.exists(ROOM_FILE):
        return False

    # Check if the room is occupied
    with open(TENANT_FILE, "r") as file:
        for line in file:
            tenant_data = line.strip().split(" | ")
            if tenant_data[3] == room_no:  # Room No is in 4th column
                return False  # Room is occupied

    # Remove room from list
    with open(ROOM_FILE, "r") as file:
        lines = file.readlines()

    found = False
    with open(ROOM_FILE, "w") as file:
        for line in lines:
            if line.startswith(room_no + " | "):
                found = True
                continue  # Skip this line (remove room)
            file.write(line)

    return found
