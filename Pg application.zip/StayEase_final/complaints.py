# class Complaint:
#     def __init__(self, complaint_id, tenant_id, issue_type, description, date_filed, status):
#         self.complaint_id = complaint_id
#         self.tenant_id = tenant_id
#         self.issue_type = issue_type
#         self.description = description
#         self.date_filed = date_filed
#         self.status = status  # Pending/Resolved



import os
import datetime

COMPLAINT_FILE = "complaints.txt"
TENANT_FILE = "tenants.txt"

def save_complaint(tenant_id, complaint_type, details):
    if not os.path.exists(TENANT_FILE):
        return False

    # Check if tenant exists
    with open(TENANT_FILE, "r") as file:
        tenants = [line.split(" | ")[0] for line in file.readlines()]
    
    if tenant_id not in tenants:
        return False  # Invalid tenant ID

    # Save complaint with a resolution deadline (3 days later)
    complaint_id = f"C{len(open(COMPLAINT_FILE).readlines()) + 1}"
    date_filed = datetime.date.today().strftime("%Y-%m-%d")
    resolution_deadline = (datetime.date.today() + datetime.timedelta(days=3)).strftime("%Y-%m-%d")

    with open(COMPLAINT_FILE, "a") as file:
        file.write(f"{complaint_id} | {tenant_id} | {complaint_type} | {details} | {date_filed} | {resolution_deadline} | Pending\n")

    return True

def update_complaint_status(complaint_id):
    if not os.path.exists(COMPLAINT_FILE):
        return False

    with open(COMPLAINT_FILE, "r") as file:
        lines = file.readlines()

    updated = False
    with open(COMPLAINT_FILE, "w") as file:
        for line in lines:
            data = line.strip().split(" | ")
            if data[0] == complaint_id:
                data[-1] = "Resolved"
                updated = True
            file.write(" | ".join(data) + "\n")

    return updated

