import os

FEEDBACK_FILE = "feedback.txt"

def save_feedback(tenant_id, food_rating, cleanliness_rating, service_rating):
    """Save tenant feedback to a file."""
    if not os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE, "w") as file:
            file.write("Tenant ID | Food Rating | Cleanliness Rating | Service Rating\n")  # Header line
    
    with open(FEEDBACK_FILE, "a") as file:
        file.write(f"{tenant_id} | {food_rating} | {cleanliness_rating} | {service_rating}\n")
    
    return True


def get_feedback_summary():
    """Calculate the average ratings for Food, Cleanliness, and Services."""
    try:
        with open(FEEDBACK_FILE, "r") as file:
            lines = file.readlines()[1:]  # Skip the header line

        if not lines:
            return "No feedback available."

        total_food, total_cleanliness, total_service = 0, 0, 0
        count = 0

        for line in lines:
            parts = line.strip().split(" | ")
            if len(parts) == 4:
                total_food += int(parts[1])
                total_cleanliness += int(parts[2])
                total_service += int(parts[3])
                count += 1

        avg_food = round(total_food / count, 2)
        avg_cleanliness = round(total_cleanliness / count, 2)
        avg_service = round(total_service / count, 2)

        return f"Average Ratings:\nFood: {avg_food}/5\nCleanliness: {avg_cleanliness}/5\nServices: {avg_service}/5"

    except FileNotFoundError:
        return "No feedback data available."
