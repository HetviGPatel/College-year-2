import tkinter as tk
from tkinter import messagebox
import os
from datetime import datetime
from complaints import save_complaint
from feedback import save_feedback

TENANT_FILE = "tenants.txt"
COMPLAINT_FILE = "complaints.txt"

# Function to fetch tenant details from file
def get_tenant_details(tenant_id):
    if os.path.exists(TENANT_FILE):
        with open(TENANT_FILE, "r") as file:
            for line in file:
                data = line.strip().split(" | ")
                if data[0] == tenant_id:
                    return {
                        "Tenant ID": data[0],
                        "Name": data[1],
                        "Room No": data[3],
                        "Rent Status": data[-3]  
                    }
    return None

# Function to fetch complaints of the tenant
def get_complaint_history(tenant_id):
    complaints = []
    if os.path.exists(COMPLAINT_FILE):
        with open(COMPLAINT_FILE, "r") as file:
            for line in file:
                data = line.strip().split(" | ")
                if len(data) >= 7 and data[1] == tenant_id:  # Check tenant ID in 2nd column
                    complaints.append(f"{data[2]} - {data[3]} (Status: {data[-1]})")
   
    return complaints


# Function to open complaint window
def open_complaint_window(tenant_id):
    complaint_window = tk.Toplevel()
    complaint_window.title("File Complaint")
    complaint_window.geometry("300x250")

    tk.Label(complaint_window, text="Complaint Type (Food/Electricity/Other):").pack()
    entry_complaint_type = tk.Entry(complaint_window)
    entry_complaint_type.pack()

    tk.Label(complaint_window, text="Complaint Details:").pack()
    entry_complaint_details = tk.Entry(complaint_window)
    entry_complaint_details.pack()

    def file_complaint():
        complaint_type = entry_complaint_type.get().strip()
        complaint_details = entry_complaint_details.get().strip()

        if not complaint_type or not complaint_details:
            messagebox.showerror("Error", "All fields are required!")
            return

        if save_complaint(tenant_id, complaint_type, complaint_details):
            messagebox.showinfo("Success", "Complaint filed successfully!")
            complaint_window.destroy()
        else:
            messagebox.showerror("Error", "Error filing complaint!")

    btn_submit = tk.Button(complaint_window, text="Submit", command=file_complaint)
    btn_submit.pack()



RECEIPT_FOLDER = "receipts"

def view_rent_receipt(tenant_id):
    receipt_path = os.path.join(RECEIPT_FOLDER, f"{tenant_id}_receipt.txt")

    if os.path.exists(receipt_path):
        with open(receipt_path, "r") as file:
            receipt_content = file.read()

        receipt_window = tk.Toplevel()
        receipt_window.title("Rent Receipt")
        receipt_window.geometry("400x300")

        tk.Label(receipt_window, text="Rent Receipt", font=("Arial", 14)).pack()
        tk.Label(receipt_window, text=receipt_content, justify="left").pack()

    else:
        messagebox.showerror("Error", "No rent receipt found! Please check with the admin.")



VISITOR_FILE = "visitors.txt"

def log_visitor(tenant_id):
    visitor_window = tk.Toplevel()
    visitor_window.title("Log Visitor")
    visitor_window.geometry("300x300")

    tk.Label(visitor_window, text="Visitor Name:").pack()
    entry_name = tk.Entry(visitor_window)
    entry_name.pack()

    tk.Label(visitor_window, text="Purpose of Visit:").pack()
    entry_purpose = tk.Entry(visitor_window)
    entry_purpose.pack()

    checkin_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tk.Label(visitor_window, text=f"Check-in Time: {checkin_time}").pack()

    def save_visitor():
        name = entry_name.get()
        purpose = entry_purpose.get()

        if not name or not purpose:
            messagebox.showerror("Error", "All fields are required!")
            return

        with open(VISITOR_FILE, "a") as file:
            file.write(f"{tenant_id} | {name} | {purpose} | {checkin_time} | Pending\n")

        messagebox.showinfo("Success", "Visitor logged successfully!")
        visitor_window.destroy()

    tk.Button(visitor_window, text="Save", command=save_visitor).pack()


MAINTENANCE_FILE = "maintenance_requests.txt"  # File to store maintenance requests

# Function to submit a maintenance request
def save_maintenance_request(tenant_id, issue_type, issue_details):
    request_id = f"MR{int(datetime.now().timestamp())}"  # Unique request ID based on timestamp
    request_date = datetime.now().strftime("%Y-%m-%d")  # Current date

    with open(MAINTENANCE_FILE, "a") as file:
        file.write(f"{request_id} | {tenant_id} | {issue_type} | {issue_details} | {request_date} | Pending\n")

    return request_id  # Return request ID for reference

# Function to open the maintenance request form
def open_maintenance_request_window(tenant_id):
    request_window = tk.Toplevel()
    request_window.title("Request Maintenance")
    request_window.geometry("300x250")

    tk.Label(request_window, text="Issue Type (Plumbing/Electricity/Other):").pack()
    entry_issue_type = tk.Entry(request_window)
    entry_issue_type.pack()

    tk.Label(request_window, text="Issue Details:").pack()
    entry_issue_details = tk.Entry(request_window)
    entry_issue_details.pack()

    def submit_request():
        issue_type = entry_issue_type.get().strip()
        issue_details = entry_issue_details.get().strip()

        if not issue_type or not issue_details:
            messagebox.showerror("Error", "All fields are required!")
            return

        request_id = save_maintenance_request(tenant_id, issue_type, issue_details)
        messagebox.showinfo("Success", f"Maintenance Request {request_id} submitted!")
        request_window.destroy()

    tk.Button(request_window, text="Submit Request", command=submit_request).pack()




def open_feedback_window(tenant_id):
    feedback_window = tk.Toplevel()
    feedback_window.title("Give Feedback")
    feedback_window.geometry("300x300")

    tk.Label(feedback_window, text="Rate Food (1-5):").pack()
    entry_food = tk.Entry(feedback_window)
    entry_food.pack()

    tk.Label(feedback_window, text="Rate Cleanliness (1-5):").pack()
    entry_cleanliness = tk.Entry(feedback_window)
    entry_cleanliness.pack()

    tk.Label(feedback_window, text="Rate Services (1-5):").pack()
    entry_service = tk.Entry(feedback_window)
    entry_service.pack()

    def submit_feedback():
        food_rating = entry_food.get().strip()
        cleanliness_rating = entry_cleanliness.get().strip()
        service_rating = entry_service.get().strip()

        # Validate ratings (must be 1-5)
        if not (food_rating.isdigit() and cleanliness_rating.isdigit() and service_rating.isdigit()):
            messagebox.showerror("Error", "Please enter valid ratings (1-5).")
            return
        
        if not (1 <= int(food_rating) <= 5 and 1 <= int(cleanliness_rating) <= 5 and 1 <= int(service_rating) <= 5):
            messagebox.showerror("Error", "Ratings must be between 1 and 5.")
            return

        save_feedback(tenant_id, food_rating, cleanliness_rating, service_rating)
        messagebox.showinfo("Success", "Feedback submitted successfully!")
        feedback_window.destroy()

    tk.Button(feedback_window, text="Submit Feedback", command=submit_feedback).pack()



# Tenant Dashboard
def tenant_dashboard(tenant_id):
    tenant_data = get_tenant_details(tenant_id)

    if not tenant_data:
        messagebox.showerror("Error", "Tenant details not found!")
        return

    root = tk.Tk()
    root.title("Tenant Dashboard")
    root.state("zoomed")  # Full-Screen Mode
    root.configure(bg="#D6EAF8")  

    # 🔹 Left Content Frame (White Card)
    content_frame = tk.Frame(root, bg="white", padx=50, pady=50, relief="solid", borderwidth=2)
    content_frame.place(relx=0.2, rely=0.5, anchor="w")  # Position on the left

    # 🔹 Sidebar (Stylish Gradient)
    sidebar = tk.Canvas(root, width=250, height=900, bg="#1976D2", highlightthickness=0)
    sidebar.place(relx=0.8, rely=0.5, anchor="e")  # Position on the right
    sidebar.create_rectangle(0, 0, 250, 900, fill="#1976D2", outline="")

    # 🔹 Welcome Label (Big & Bold)
    tk.Label(content_frame, text=f"Welcome, {tenant_data['Name']}!", font=("Arial", 24, "bold"), bg="white", fg="#333").pack(pady=20)

    # 🔹 Display Tenant Info
    tk.Label(content_frame, text=f"Tenant ID: {tenant_data['Tenant ID']}", font=("Arial", 16), bg="white", fg="#444").pack(pady=5, anchor="w")
    tk.Label(content_frame, text=f"Room No: {tenant_data['Room No']}", font=("Arial", 16), bg="white", fg="#444").pack(pady=5, anchor="w")
    tk.Label(content_frame, text=f"Rent Status: {tenant_data['Rent Status']}", font=("Arial", 16), bg="white", fg="#444").pack(pady=5, anchor="w")

    # 🔹 Stylish Button Function (Rounded + Hover Effects)
    def create_button(text, command, y_pos):
        btn = tk.Button(root, text=text, font=("Arial", 14, "bold"), bg="white", fg="#333",
                        width=20, height=2, relief="flat", bd=3, highlightthickness=2, highlightbackground="#1976D2",
                        command=command, cursor="hand2")
        btn.place(relx=0.82, rely=y_pos, anchor="center")

        # 🔹 Hover Effect
        btn.bind("<Enter>", lambda e: btn.config(bg="#1565C0", fg="white"))  # Dark Blue on Hover
        btn.bind("<Leave>", lambda e: btn.config(bg="white", fg="#333"))  # Normal White

    # 🔹 Buttons in Sidebar
    create_button("View Rent Receipt", lambda: view_rent_receipt(tenant_id), 0.3)
    create_button("Log Visitor", lambda: log_visitor(tenant_id), 0.38)
    create_button("Request Maintenance", lambda: open_maintenance_request_window(tenant_id), 0.46)
    create_button("Give Feedback", lambda: open_feedback_window(tenant_id), 0.54)
    create_button("File Complaint", lambda: open_complaint_window(tenant_id), 0.62)
    create_button("Logout", root.destroy, 0.70)

    root.mainloop()



# If running directly, use a test tenant ID
if __name__ == "__main__":
    test_tenant_id = "T001"  # Change this to an existing tenant ID for testing
    tenant_dashboard(test_tenant_id)
